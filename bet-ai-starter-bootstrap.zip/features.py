"""Feature engineering.

Replace this with your real feature logic.
"""

import pandas as pd

def make_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Example: expects a target column named 'y'."""
    if "y" not in df.columns:
        raise ValueError("Expected a target column named 'y' in your dataset.")
    y = df["y"]
    X = df.drop(columns=["y"])
    return X, y
