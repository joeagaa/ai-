# 🧠 Bet AI Starter

An AI-powered sports betting starter project with training, backtesting, paper trading, and built-in risk management.

> ⚠️ **Disclaimer:** This project is for educational and research purposes only. Sports betting involves risk. There is no guarantee of profit. Do not risk money you can’t afford to lose.

## 🚀 What’s inside

- `config.py` — configuration (paths, thresholds, etc.)
- `features.py` — feature engineering
- `train_backtest.py` — training + backtesting + model saving
- `live_paper.py` — paper trading (loads the saved model)
- `safety.py` — bankroll & risk management helpers
- `data/` — place raw/processed datasets here (kept empty by default)
- `out/` — generated outputs (models, logs)

## 📦 Setup

```bash
python -m venv .venv
source .venv/bin/activate  # (Windows: .venv\Scripts\activate)
pip install -r requirements.txt
```

## 🧪 Train & Backtest

```bash
python train_backtest.py
```

- Saves model into `out/models/`
- Writes metrics/logs into `out/logs/`

## 📈 Paper Trading

```bash
python live_paper.py
```

## 🔐 Secrets

If you use API keys, put them in `.env` and do **not** commit it.

Example:
```bash
API_KEY=your_key_here
```

## 📜 License

MIT
