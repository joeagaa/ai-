"""Project configuration."""

from dataclasses import dataclass

@dataclass(frozen=True)
class Paths:
    data_dir: str = "data"
    out_dir: str = "out"
    models_dir: str = "out/models"
    logs_dir: str = "out/logs"

@dataclass(frozen=True)
class Risk:
    # Example guardrails (tune later)
    max_bet_pct_bankroll: float = 0.02
    max_daily_loss_pct: float = 0.05
    min_confidence_to_bet: float = 0.55

PATHS = Paths()
RISK = Risk()
